package br.com.rha;

public class principal {

	public static <T> void main(String[] args) {
		// TODO Auto-generated method stub
		int nFluxo = 1;
		Deque deque = new Deque(15);
		Deque deque1 = new Deque(5);

		Deque deque2 = new Deque(5);

		Deque deque3 = new Deque(5);
		
		Deque fila1 = new Deque(5);

		Deque fila2 = new Deque(5);

		Deque fila3 = new Deque(5);
		
		for(int i = 0 ; i <5 ; i++) {
			try {
			deque1.enqueueRight(11 + ( i * 11));
			deque2.enqueueRight(12 + ( i * 11));
			deque3.enqueueRight(13 + ( i * 11));
			}catch(Exception e) {
				System.out.println("Erro: " + e.getMessage());
			}
		}
		
		int[] cont = {0,0,0};
		boolean veri = deque.isFull();
		
		
		while(!veri) {
			switch(nFluxo) {
			case 1:
				try {
				Pacote p = new Pacote(nFluxo,(int)deque1.dequeueLeft());
				deque.enqueueRight(p);
				}catch(Exception e) {
					System.out.println("Erro: " + e.getMessage());
				}
				nFluxo = 2;
				veri = deque.isFull();
				break;
			case 2:
				try {
				Pacote p2 = new Pacote(nFluxo,(int)deque2.dequeueLeft());
				deque.enqueueRight(p2);
				}catch(Exception e) {
					System.out.println("Erro: " + e.getMessage());
				}
				nFluxo = 3;
				veri = deque.isFull();
				break;
			case 3:
				try {
				Pacote p3 = new Pacote(nFluxo,(int)deque3.dequeueLeft());
				deque.enqueueRight(p3);
				}catch(Exception e) {
					System.out.println("Erro: " + e.getMessage());
				}
				nFluxo = 1;
				veri = deque.isFull();
				break;
			}
		}
		System.out.println(deque);
		System.out.println("----------------------------------------------------------");
		int size = deque.size();
		Pacote p2 = new Pacote();
		int nFluxo2 = 0;
		for(int i =0; i < size;i++) {
			try {
				p2 = (Pacote) deque.dequeueRight();
				nFluxo2 = p2.getNum1();
				switch(nFluxo2) {
				case 1:
					fila1.enqueueRight(p2);
				break;
				case 2:
					fila2.enqueueRight(p2);
				break;
				case 3:
					fila3.enqueueRight(p2);
				break;
				}
			} catch (Exception e) {
				System.out.println("Erro: " + e.getMessage());
			}
			System.out.println(fila1);
			System.out.println("----------------------------------------------------------");
			System.out.println(fila2);
			System.out.println("----------------------------------------------------------");
			System.out.println(fila3);
			System.out.println("----------------------------------------------------------");
		}
	}
}

package br.com.rha;

public class Pacote {
	private int num1;
	private int num2;
	public Pacote(int num1, int num2) {
		this.num1 = num1;
		this.num2 = num2;
	}

	public Pacote() {
		this.num1 = 0;
		this.num2 = 0;
	}


	public int getNum1() {
		return num1;
	}

	public void setNum1(int num1) {
		this.num1 = num1;
	}

	public int getNum2() {
		return num2;
	}

	public void setNum2(int num2) {
		this.num2 = num2;
	}

	public String mandar() {
		return "(" + this.num1 + "," + this.num2 + ")";
	}
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("(")
			.append(num1)
			.append(",")
			.append(num2)
			.append(")");
		
		return sb.toString();
			
	}
}

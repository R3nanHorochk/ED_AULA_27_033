package br.com.rha;

public class Deque2<T> {
	private static final int TAM_DEQUE = 100;
	private	int inicio, fim, qtde,tamanho;
	private T e[ ];	
	// Construtor que Inicia o Deque d
	// como vazio e tamanho padrão
	public	Deque2() {
		this(TAM_DEQUE);
	}
	// Construtor que Inicia o Deque d
	// como vazio e tamanho informado
	// pelo usuário da classe
	public Deque2(int tamanho) {
		this.inicio = 0;
		this.fim = 0;
		this.qtde = 0;
		this.tamanho = tamanho;
		this.e = (T[])new Object [tamanho];
	}
	// Verifica se o Deque d está vazio
	// retornando true (se vazio)
	// e false (caso contrário)
	public boolean dIsEmpty( ) {
		return qtde == 0;
	}
	// Verifica se o Deque d está cheio
	// retornando true (se cheio)
	// e false (caso contrário)

	public boolean dIsFull( ) {
		return qtde == this.tamanho;
	}
	// Obtém o elemento do início do Deque
	public T getLeft ( )throws Exception {
		if (! dIsEmpty( )){
		    return e[inicio];
		} else {
			throw new Exception("deque empty");
		   
		} 		
	}
	// Obtém o elemento do fim do deque D
	public T getRight ( )throws Exception {
		if (! dIsEmpty( )){
		    if (fim == 0)
		      return e[TAM_DEQUE-1];
		    else
		      return e[fim-1];
		} else {
			throw new Exception("deque empty");
		} 
	}
	// Insere no “início-1” do Deque D
	public void enqueueLeft ( T e ) {
		if (! dIsFull( )){
		    if (inicio == 0){
		      this.e[TAM_DEQUE-1] = e;
		      inicio = TAM_DEQUE-1;
		    } else this.e[--inicio] = e;
		    qtde++;
		  } else 
			  System.out.println("deque overflow");		
	}
	// Insere no “fim” do Deque D
	public void enqueueRight ( T e ) {
		if (! dIsFull( )){
		    this.e[fim++] = e;
		    fim = fim % TAM_DEQUE;
		    qtde++;
		} else 
		    System.out.println("deque overflow");
		
	}
	// Remove e retorna um elemento do início do Deque d
	public T dequeueLeft( )throws Exception {
		T aux;
		if (! dIsEmpty( )){
		   aux = e[inicio];
		   inicio = ++inicio % TAM_DEQUE;
		   qtde--;
		   return aux;
		}else{
			throw new Exception("deque empty");
		}
	}	
	// Remove e retorna um elemento  do final do Deque d
	public T dequeueRight( )throws Exception {
		  T aux;
		  if (! dIsEmpty( )){
		    if (fim == 0) {
		      aux = e[this.tamanho-1];
		      fim = TAM_DEQUE-1;
		    } else {
		      aux = e[fim-1];
		      fim--;
		    }
		    qtde--;
		    return aux;
		  }else{
			  throw new Exception("deque empty");
			  } 		
	}	
	// Retorna o total de elementos
	// armazenados no deque
	public int size() {
		return qtde;
	}
	
	@Override
	public String toString() {
		
		int indiceNovo = (inicio + qtde) % e.length;
		
		StringBuilder sb = new StringBuilder();
		sb.append("[Deque] quantidade: ")
			.append(qtde)
			.append(", capacidade: ")
			.append(e.length);
		if (qtde != 0) {
			try {
			sb.append(", primeiro (Esquerda): ")
				.append(getLeft())
				.append(", último (Direita): ")
				.append(getRight());
			}catch(Exception e) {
				System.out.println("Erro: " + e.getMessage());
			}
			
		} 
		
		sb.append("\nConteudo do Deque': [ ");
		if (qtde != 0) {
			if (indiceNovo <= inicio) {
				for (int i = inicio; i < e.length; ++i)
					sb.append("[" + e[i] + "]");
				for (int i = 0; i < indiceNovo; ++i)
					sb.append("[" + e[i] + "]");
			} else {
				for (int i = inicio; i < indiceNovo; ++i)
					sb.append("[" + e[i] + "]");
			}
		}
		sb.append(" ]");
		return sb.toString();
	}

}
